#include <time.h>
#include "rtc.h"

void RTC_Init(void)
{
    RTC_InitTypeDef  RTC_InitStructure;

    RTC_InitStructure.RTC_TMR1.NewState = ENABLE;               /*!< ʹ��RTC��ʱ��1              */
    RTC_InitStructure.RTC_TMR1.Count = 5;                       /*!< ��ʱ����6s                  */
    RTC_InitStructure.RTC_TMR2.NewState = DISABLE;              /*!< �ر�RTC��ʱ��2              */
    RTC_InitStructure.RTC_TMR1.Count = 0;
    RTC_InitStructure.RTC_Alarm.Muster.hour = 0x99;             /*!< ����������                  */
    RTC_InitStructure.RTC_Alarm.Muster.minute = 0x99;
    RTC_InitStructure.RTC_TOUT = Tout1Hz;                       /*!< Tout���1Hz                 */
    HT_RTC_Init(&RTC_InitStructure);
	
	//RTC��������
	EnWr_WPREG();
//	HT_TBS->TBSCON = 0x0301;
//	HT_TBS->TBSIE = 0x00;
//	HT_TBS->TBSPRD = 0x00;
	HT_RTC_LoadInfoData();
}

static char gTimeStr[16];

char* GetCurrentTime(void)
{
    uint8_t day[8];

    HT_RTC_Read(day);
    sprintf(gTimeStr,"%02u-%02u %02u:%02u:%02u", day[2], day[3], day[4], day[5], day[6]);
    return gTimeStr;
}

int LinuxTickToDay(uint32_t tick, uint8_t *pDay)
{
    struct tm *time_now;
    time_t time_unix;

	time_unix = tick;
	time_now = localtime(&time_unix);
    pDay[0] = time_now->tm_wday;
    pDay[1] = time_now->tm_year - 100;
    pDay[2] = time_now->tm_mon+1;
    pDay[3] = time_now->tm_mday;
    pDay[4] = time_now->tm_hour;
    pDay[5] = time_now->tm_min;
    pDay[6] = time_now->tm_sec;
    return CL_OK;
}


//
void SetRtcCount(time_t timestamp)
{
    uint8_t day[8];

    LinuxTickToDay(timestamp+8*60*60, day);
	
    HT_RTC_Write(day);
}


time_t GetTimeStamp(void)
{
	struct tm time_now;
	memset(&time_now,0,sizeof(struct tm));
	uint8_t day[8];
    HT_RTC_Read(day);
	time_now.tm_wday = day[0];
	time_now.tm_year = day[1]+100;
	time_now.tm_mon =  day[2]-1;
	time_now.tm_mday = day[3];
	time_now.tm_hour = day[4]-8;
	time_now.tm_min =  day[5];
	time_now.tm_sec =  day[6];
	
	return mktime(&time_now);
}




