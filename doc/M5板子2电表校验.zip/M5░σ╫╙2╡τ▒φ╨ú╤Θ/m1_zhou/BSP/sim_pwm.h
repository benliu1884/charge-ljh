#ifndef __ADC_H__
#define __ADC_H__

#include "includes.h"


void SimPwm_Init(void);
void StartPwm(void);
void StopPwm(void);

#endif
