#ifndef __PMU_H__
#define __PMU_H__

#include "includes.h"

void PMU_Init(void);
void Enter_StandBy(void);
void PowerOff_MCU(void);
void enter_hold_init(void);

#endif
