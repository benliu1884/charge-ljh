#ifndef __DELAY_H__
#define __DELAY_H__

#include <stdint.h>


void Delay_mSec(int mSec);

void Delay_100uSec(int count);


#endif

